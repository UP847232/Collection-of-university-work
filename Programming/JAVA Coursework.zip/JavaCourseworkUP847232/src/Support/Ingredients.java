package Support;

public class Ingredients {
    public enum Size {
        Small(9.45), Medium(11.87), Large(15.90);
        private double value;
        Size(double value){this.value = value;}
        public double getValue(){return this.value;}
    }
    public enum Crust {
        Thin(1.08), Deep(1.10), Stuffed(2.14);
        private double value;
        Crust(double value){this.value = value;}
        public double getValue(){return this.value;}
    }
    public enum Topping {
        None(0.00), Extra_Cheese(0.02), Mushroom(0.03), Rocket(0.05), Chilli(0.06),
        Onion(0.07), Olive(0.08), Anchovy(0.09), Pepperoni(0.10), Jalapenos(0.20);
        private double value;
        Topping(double value){this.value = value;}
        public double getValue(){return this.value;}
    }
    public enum Sauce {
        Tomato(0.00), Pesto(0.50);
        private double value;
        Sauce(double value){this.value = value;}
        public double getValue(){return this.value;}
    }
}
