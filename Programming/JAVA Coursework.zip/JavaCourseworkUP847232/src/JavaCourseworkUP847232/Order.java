package JavaCourseworkUP847232;
import Support.Ingredients;
import java.util.*;

public class Order {
    private ArrayList<Pizza> pizzas;
    
    public Order(){
        pizzas = new ArrayList<Pizza>();
    }
    
    public void addPizza(Ingredients.Size size, Ingredients.Crust crust,
                         Ingredients.Topping topping1, Ingredients.Topping topping2,
                         Ingredients.Sauce sauce){
        Pizza p = new Pizza(size, crust, topping1, topping2, sauce);
        pizzas.add(p);
    }
    
    public void removePizza(int index){
        Pizza myPizza = this.pizzas.get(index - 1);
        this.pizzas.remove(myPizza);
    }
    
    public void editSize(int index, Ingredients.Size size){
        Pizza myPizza = this.pizzas.get(index - 1);
        myPizza.setSize(size);
    }
    
    public void editCrust(int index, Ingredients.Crust crust){
        Pizza myPizza = this.pizzas.get(index - 1);
        myPizza.setCrust(crust);
    }

    public void editTopping1(int index, Ingredients.Topping topping){
        Pizza myPizza = this.pizzas.get(index - 1);
        myPizza.setTopping1(topping);
    }
    
    public void editTopping2(int index, Ingredients.Topping topping){
        Pizza myPizza = this.pizzas.get(index - 1);
        myPizza.setTopping2(topping);
    }
    
    public void editSauce(int index, Ingredients.Sauce sauce){
        Pizza myPizza = this.pizzas.get(index - 1);
        myPizza.setSauce(sauce);
    }
    
    public int getNumOfPizzas(){
        return this.pizzas.size();
    }
    
    public String getTotalOrderCost(){
        double totalOrderCost = 0;
        double scale = Math.pow(10,2);
        for(Pizza myPizza:pizzas){
            totalOrderCost += myPizza.getTotalCost();
        }
        return String.format("£%.2f",totalOrderCost);
    }
    
    public String getPizzaInfo(int index){
        Pizza myPizza = this.pizzas.get(index - 1);
        String pizzaInfo = myPizza.getPizzaInfo();
        return pizzaInfo;
    }
    
    public String getOrderInfo(){
        String orderInfo = "";
        for(Pizza myPizza:pizzas){
            orderInfo += myPizza.getPizzaInfo() + "\n";
        }
        return orderInfo;
    }
}
