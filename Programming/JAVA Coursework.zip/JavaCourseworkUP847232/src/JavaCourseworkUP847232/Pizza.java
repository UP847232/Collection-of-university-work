package JavaCourseworkUP847232;
import Support.Ingredients;

public class Pizza {
    private Ingredients.Size size;
    private Ingredients.Crust crust;
    private Ingredients.Topping topping1;
    private Ingredients.Topping topping2;
    private Ingredients.Sauce sauce;
    
    public Pizza(Ingredients.Size size, Ingredients.Crust crust,
                 Ingredients.Topping topping1, Ingredients.Topping topping2,
                 Ingredients.Sauce sauce){
        this.size = size;
        this.crust = crust;
        this.topping1 = topping1;
        this.topping2 = topping2;
        this.sauce = sauce;
    }
    // Setters
    public void setSize(Ingredients.Size newSize){this.size = newSize;}
    public void setCrust(Ingredients.Crust newCrust){this.crust = newCrust;}
    public void setTopping1(Ingredients.Topping newTopping1){this.topping1 = newTopping1;}
    public void setTopping2(Ingredients.Topping newTopping2){this.topping2 = newTopping2;}
    public void setSauce(Ingredients.Sauce newSauce){this.sauce = newSauce;}

    // Getters
    public Ingredients.Size getSize(){return this.size;}
    public Ingredients.Crust getCrust(){return this.crust;}
    public Ingredients.Topping getTopping1(){return this.topping1;}
    public Ingredients.Topping getTopping2(){return this.topping2;}
    public Ingredients.Sauce getSauce(){return this.sauce;}
    
    public double getSizeCost(){return this.size.getValue();}
    public double getCrustCost(){return this.crust.getValue();}
    public double getBaseCost(){return getSizeCost() + getCrustCost();}
    public double getTopping1Cost(){return this.topping1.getValue();}
    public double getTopping2Cost(){return this.topping2.getValue();}
    public double getSauceCost(){return this.sauce.getValue();}
    public double getTotalCost(){
        return getBaseCost() + (getTopping1Cost()*5) +
               (getTopping2Cost()*4) + getSauceCost();
    }
    
    public String getPizzaInfo(){
        String info = String.format("TOTAL COST: £%.2f \n" +
                                    "%s Size: £%.2f \n" +
                                    "%s Crust: £%.2f \n" +
                                    "BASE COST: £%.2f \n" +
                                    "%s Topping: 5 * £%.2f = £%.2f \n" +
                                    "%s Topping: 4 * £%.2f = £%.2f \n" +
                                    "%s Sauce: £%.2f \n",
                                    getTotalCost(), size,getSizeCost(), crust,
                                    getCrustCost(), getBaseCost(), topping1,
                                    getTopping1Cost(), (getTopping1Cost() * 5),
                                    topping2,getTopping2Cost(),
                                    (getTopping2Cost() * 4),
                                    sauce,getSauceCost());
        return info;
    }
}
