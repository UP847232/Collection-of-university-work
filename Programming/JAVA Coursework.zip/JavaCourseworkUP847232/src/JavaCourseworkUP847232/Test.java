package JavaCourseworkUP847232;
import Support.Ingredients;

public class Test {

    public static void main(String[] args) {
    // ---------------------- PIZZA CLASS TEST SCRIPT ---------------------- \\
        System.out.println("========================================\n" +
                           "            PIZZA CLASS TEST\n" +
                           "========================================");
        // CREATE PIZZA
        System.out.println("CREATION OF PIZZA (w/Following Data):\n" +
                           "[] Size.Medium \n" +
                           "[] Crust.Stuffed \n" +
                           "[] Topping.Olive \n" +
                           "[] Topping.Onion \n" +
                           "[] Sauce.Pesto \n");
        Pizza myPizza = new Pizza(Ingredients.Size.Medium,
                                  Ingredients.Crust.Stuffed,
                                  Ingredients.Topping.Olive,
                                  Ingredients.Topping.Onion,
                                  Ingredients.Sauce.Pesto);
        printPizzaInfo(myPizza);
        // EDIT PIZZA
        System.out.println("EDITING OF PIZZA VIA USE OF SET MEDTHODS:\n" +
                           "[] Size.Small \n" +
                           "[] Crust.Thin \n" +
                           "[] Topping.Chilli \n" +
                           "[] Topping.Pepperoni \n");
        myPizza.setSize(Ingredients.Size.Small);
        myPizza.setCrust(Ingredients.Crust.Thin);
        myPizza.setTopping1(Ingredients.Topping.Chilli);
        myPizza.setTopping2(Ingredients.Topping.Pepperoni);
        printPizzaInfo(myPizza);
    
    // ---------------------- ORDER CLASS TEST SCRIPT ---------------------- \\
        System.out.println("========================================\n" +
                           "            ORDER CLASS TEST\n" +
                           "========================================");
        // CREATE ORDER
        Order myOrder = new Order();
        // ADD PIZZAS TO ORDER
        System.out.println("PIZZA 1 - CREATE & ADD TO ORDER:\n" +
                           "[] Size.Medium \n" +
                           "[] Crust.Thin \n" +
                           "[] Topping.Extra_Cheese \n" +
                           "[] Topping.Chilli \n" +
                           "[] Sauce.Pesto \n");
        myOrder.addPizza(Ingredients.Size.Medium,
                         Ingredients.Crust.Thin,
                         Ingredients.Topping.Extra_Cheese,
                         Ingredients.Topping.Chilli,
                         Ingredients.Sauce.Pesto);
        System.out.println("PIZZA 2 - CREATE & ADD TO ORDER:\n" +
                           "[] Size.Medium \n" +
                           "[] Crust.Stuffed \n" +
                           "[] Topping.Olive \n" +
                           "[] Topping.Onion \n" +
                           "[] Sauce.Pesto \n");
        myOrder.addPizza(Ingredients.Size.Medium,
                         Ingredients.Crust.Stuffed,
                         Ingredients.Topping.Olive,
                         Ingredients.Topping.Onion,
                         Ingredients.Sauce.Pesto);
        System.out.println("PIZZA 3 - CREATE & ADD TO ORDER:\n" +
                           "[] Size.Small \n" +
                           "[] Crust.Thin \n" +
                           "[] Topping.Chilli \n" +
                           "[] Topping.Pepperoni \n" +
                           "[] Sauce.Pesto \n");
        myOrder.addPizza(Ingredients.Size.Small,
                         Ingredients.Crust.Thin,
                         Ingredients.Topping.Chilli,
                         Ingredients.Topping.Pepperoni,
                         Ingredients.Sauce.Pesto);
        System.out.println("PIZZA 4 - CREATE & ADD TO ORDER:\n" +
                           "[] Size.Small \n" +
                           "[] Crust.Thin \n" +
                           "[] Topping.Olive \n" +
                           "[] Topping.Olive \n" +
                           "[] Sauce.Pesto \n");
        myOrder.addPizza(Ingredients.Size.Small,
                         Ingredients.Crust.Thin,
                         Ingredients.Topping.Olive,
                         Ingredients.Topping.Olive,
                         Ingredients.Sauce.Pesto);
        printOrderInfo(myOrder);
        // REMOVE PIZZA FROM ORDER
        System.out.println("DELETION OF PIZZA 3 FROM ORDER:\n" +
                           "[] Deletes pizza 3 from arrylist via it's index value \n");
        myOrder.removePizza(3);
        printOrderInfo(myOrder);
        // EDIT PIZZA IN ORDER
        System.out.println("EDIT PIZZA 4 WITHIN ORDER VIA USE OF SET MEDTHODS:\n" +
                           "[] 3, Size.Small \n" +
                           "[] 3, Crust.Thin \n" +
                           "[] 3, Topping.Chilli \n" +
                           "[] 3, Topping.Pepperoni \n");
        myOrder.editSize(3, Ingredients.Size.Small);
        myOrder.editCrust(3, Ingredients.Crust.Thin);
        myOrder.editTopping1(3, Ingredients.Topping.Chilli);
        myOrder.editTopping2(3, Ingredients.Topping.Pepperoni);
        printOrderInfo(myOrder);
        // CALCULATE TOTAL COST OF ORDER
        System.out.println("CALCULATE TOTAL COST OF ORDER VIA GET METHOD:");
        System.out.println(myOrder.getTotalOrderCost());
        // CALCULATE NUMBER OF PIZZAS IN ORDER
        System.out.println("CALCULATE NUMBER OF PIZZAS IN ORDER VIA GET METHOD:");
        System.out.println(myOrder.getNumOfPizzas());
    }
    
    // ------------------------- DISPLAY INFO CODE ------------------------- \\
    public static void printPizzaInfo(Pizza myPizza){
        System.out.println("               PIZZA INFO\n" +
                           "----------------------------------------");
        System.out.println(myPizza.getPizzaInfo() + "\n");
    }
    public static void printOrderInfo(Order myOrder){
        System.out.println("               ORDER INFO\n" +
                           "----------------------------------------");
        System.out.println(myOrder.getOrderInfo());
    }
}
