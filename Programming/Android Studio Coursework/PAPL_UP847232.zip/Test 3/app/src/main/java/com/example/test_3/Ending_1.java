package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Ending_1 extends AppCompatActivity implements View.OnClickListener {
    private Button endbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ending_1);

        endbtn = (Button) findViewById(R.id.action_btnEnd);
        endbtn.setOnClickListener(this);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Ending_1.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {
        finish();
    }

    @Override
    public void onClick(View v) {
        if (endbtn.getText().toString().equals("Go to the relevant office")) {
            endbtn.setText("Go from office to office");
        }
        else {
            TextView result = (TextView) findViewById(R.id.result_tv);
            result.setVisibility(View.VISIBLE);
            endbtn.setVisibility(View.GONE);
        }
    }
}
