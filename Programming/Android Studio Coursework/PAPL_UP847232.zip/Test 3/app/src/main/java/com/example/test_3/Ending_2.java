package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Ending_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ending_2);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Ending_2.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {finish();}
}
