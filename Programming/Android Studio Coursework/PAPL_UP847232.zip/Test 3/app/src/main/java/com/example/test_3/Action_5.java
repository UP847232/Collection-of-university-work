package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Action_5 extends AppCompatActivity implements View.OnClickListener {
    private Button actbtnact5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_5);

        actbtnact5 = (Button) findViewById(R.id.action_btnact5);
        actbtnact5.setOnClickListener(this);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Action_5.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {
        finish();
    }

    @Override
    public void onClick(View v) {
        if (actbtnact5.getText().toString().equals("EMERGENCY")) {
            actbtnact5.setText("Put Mr X in quarantine for 40 days!");
        }
        else {
            Intent myIntent2 = new Intent(Action_5.this,Loopback.class);
            startActivity(myIntent2);
        }
    }
}
