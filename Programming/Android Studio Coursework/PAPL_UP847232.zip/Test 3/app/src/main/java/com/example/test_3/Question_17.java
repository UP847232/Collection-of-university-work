package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Question_17 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_17);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Question_17.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {
        finish();
    }

    public void yesClickHandler(View view) {
        Intent myIntent = new Intent(Question_17.this,Action_5.class);
        startActivity(myIntent);
    }

    public void noClickHandler(View view) {
        Intent myIntent = new Intent(Question_17.this,Action_8.class);
        startActivity(myIntent);
    }
}
