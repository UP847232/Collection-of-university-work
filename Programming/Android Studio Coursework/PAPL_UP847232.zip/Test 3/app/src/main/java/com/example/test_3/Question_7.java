package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Question_7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_7);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Question_7.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {
        finish();
    }

    public void yesClickHandler(View view) {
        Intent myIntent = new Intent(Question_7.this,Question_8.class);
        startActivity(myIntent);
    }

    public void noClickHandler(View view) {
        Intent myIntent = new Intent(Question_7.this,Loopback.class);
        startActivity(myIntent);
    }
}
