package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Action_13 extends AppCompatActivity implements View.OnClickListener {

    private Button actbtnact13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_13);

        actbtnact13 = (Button) findViewById(R.id.action_btnact13);
        actbtnact13.setOnClickListener(this);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Action_13.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {
        finish();
    }

    @Override
    public void onClick(View v) {
        if (actbtnact13.getText().toString().equals("Send Mr X to TV1")) {
            actbtnact13.setText("Leave him to absorb the message");
        }
        else {
            Intent myIntent = new Intent(Action_13.this,Loopback.class);
            startActivity(myIntent);
        }
    }
}
