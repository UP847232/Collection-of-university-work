package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Question_5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_5);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Question_5.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {
        finish();
    }

    public void actionClickHandler(View view) {
        TextView question = (TextView) findViewById(R.id.question_tv5);
        question.setVisibility(View.VISIBLE);
        findViewById(R.id.yes_btn5).setVisibility(View.VISIBLE);
        findViewById(R.id.no_btn5).setVisibility(View.VISIBLE);
        findViewById(R.id.action_btn5).setVisibility(View.GONE);
    }

    public void yesClickHandler(View view) {
        Intent myIntent = new Intent(Question_5.this,Question_6.class);
        startActivity(myIntent);
    }

    public void noClickHandler(View view) {
        Intent myIntent = new Intent(Question_5.this,Loopback.class);
        startActivity(myIntent);
    }
}
