package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Action_10 extends AppCompatActivity implements View.OnClickListener {
    private Button actbtnact10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_10);

        actbtnact10 = (Button) findViewById(R.id.action_btnact10);
        actbtnact10.setOnClickListener(this);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Action_10.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {finish();}

    @Override
    public void onClick(View v) {
        if (actbtnact10.getText().toString().equals("Return to your desk")) {
            actbtnact10.setText("Ponder your next problem");
        }
        else {
            Intent myIntent = new Intent(Action_10.this,Loopback.class);
            startActivity(myIntent);
        }
    }
}
