package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Question_22 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_22);
    }

    public void returnClickHandler(View view) {
        Intent myIntent = new Intent(Question_22.this,MainActivity.class);
        startActivity(myIntent);
    }

    public void backClickHandler(View view) {
        finish();
    }

    public void yesClickHandler(View view) {
        Intent myIntent = new Intent(Question_22.this,Question_28.class);
        startActivity(myIntent);
    }

    public void noClickHandler(View view) {
        Intent myIntent = new Intent(Question_22.this,Question_23.class);
        startActivity(myIntent);
    }
}
