package com.example.test_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Loopback extends AppCompatActivity implements View.OnClickListener {
    private Button loopbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loopback);

        loopbtn = (Button) findViewById(R.id.Loopback_btn);
        loopbtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (loopbtn.getText().toString().equals("Think hard")) {
            loopbtn.setText("Firmly decide");
        }
        else {
            Intent myIntent = new Intent(Loopback.this,Question_1.class);
            startActivity(myIntent);
        }
    }
}
